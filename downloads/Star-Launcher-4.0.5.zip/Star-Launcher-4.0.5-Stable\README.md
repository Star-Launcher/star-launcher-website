# Star-Launcher 4.0.5 Stable

Built: 2026-08-02 14:25:54 UTC

Star-Launcher is a portable Windows x64 application for coordinating configurable
pre-launch workflows for space, flight, and racing simulators.

## Run

1. Extract the complete ZIP to a writable folder.
2. Run `Star-Launcher.exe`.
3. Configure only the tools and launch actions you want.

No installer or background service is included. Star-Launcher stores user
configuration under `%APPDATA%\Star-Launcher`; upgrading the portable executable
does not remove existing profiles or controller presets.

## Updates

Use **Settings > Preferences > Check for updates now** to check the stable
release feed. Star-Launcher asks before downloading and again before it closes,
installs the verified portable package, and restarts. The download must match the
published byte size and SHA-256 checksum. If this folder is not writable, use the
manual-download option and extract the complete release yourself.

Windows may show its normal downloaded-file warning. Verify the SHA-256 checksum
from the release before running files obtained from a third party.

## Requirements

- Windows 10 or Windows 11, x64
- .NET Framework 4.8
- Any companion tools selected by the user

Third-party controller tools, game launchers such as RSI Launcher, browsers, and
companion applications are not bundled.

## Package contents

- `Star-Launcher.exe`
- `README.md`
- `SHA256SUMS.txt`
- `release-manifest.json`

## Safety boundaries

Star-Launcher does not automate credentials, CAPTCHA, 2FA, UAC approval, gameplay,
or anti-cheat bypasses. Native game-launcher integrations, including RSI Launcher,
and controller-tool automation retain visible timeouts, errors, cancellation, and
manual fallbacks. The self-updater never silently requests elevation and never
replaces user data.
