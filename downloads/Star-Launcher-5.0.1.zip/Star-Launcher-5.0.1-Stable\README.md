# Star-Launcher 5.0.1 Stable

Built: 2026-08-11 16:25:46 UTC

Star-Launcher is a portable Windows x64 application for coordinating configurable
pre-launch workflows for space, flight, and racing simulators.

## Run

1. Place the complete release contents in a writable folder.
2. Run `Star-Launcher.exe`.
3. Select a native game tile, or use the **Add game** tile for another title.
4. Open **Settings > Setup** to configure that game's launch methods,
   game-specific apps, keybind viewers, and web resources.
5. Configure universal Utility Apps and choose or create an independent controller
   preset if your setup uses controller preparation.
6. Return to Main, select the actions to include, run **Pre-flight checks**, and
   launch the game. Use **Reorder** on Main whenever you want to rearrange tiles.

No installer or background service is included. Star-Launcher stores user
configuration under `%APPDATA%\Star-Launcher`; upgrading the portable executable
does not remove existing game settings or controller presets.

Game settings and shared tool paths save automatically. Preferences apply to the
app as a whole, while each game remembers which launch methods, apps, resources,
and controller preset it uses.

## 5.0 game data

This release stores its game configurations in the separate, backward-compatible
`game-settings-v5-preview.json` file retained from 5.0 testing. It does not overwrite the 4.0
`profiles.json` collection. On first run, the last-used 4.0 Star Citizen profile
is copied into the Star Citizen game configuration; the original remains intact.
Game settings save automatically. Launch Options and the rest of Preferences are
universal user settings rather than part of an individual game. Automatic profile
launch at application startup is not included in 5.0.

The additional built-in games launch through Steam using their verified App IDs.
Steam handles installation, updates, ownership checks, and game-specific launch
choosers. Local launch methods can also be added. Game tiles can be reordered
directly on Main, and each game can keep multiple module-specific keybind viewers.
Automatic detection and title-specific standalone/Microsoft Store support are
planned for later updates.

## Updates

Use **Settings > Preferences > Check for updates now** to check the stable
release feed. Star-Launcher asks before downloading and again before it closes,
installs the verified portable package, and restarts. The download must match the
published byte size and SHA-256 checksum. If this folder is not writable, use the
manual-download option and extract the complete release yourself.

Windows may show its normal downloaded-file warning. Verify the SHA-256 checksum
from the release before running files obtained from a third party.

## Requirements

- Windows 10 or Windows 11, x64
- .NET Framework 4.8
- Any companion tools selected by the user

Third-party controller tools, game launchers such as RSI Launcher, browsers, and
companion applications are not bundled.

## Package contents

- `Star-Launcher.exe`
- `README.md`
- `SHA256SUMS.txt`
- `release-manifest.json`

## Safety boundaries

Star-Launcher does not automate credentials, CAPTCHA, 2FA, UAC approval, gameplay,
or anti-cheat bypasses. Native game-launcher integrations, including RSI Launcher,
and controller-tool automation retain visible timeouts, errors, cancellation, and
manual fallbacks. The self-updater never silently requests elevation and never
replaces user data.
